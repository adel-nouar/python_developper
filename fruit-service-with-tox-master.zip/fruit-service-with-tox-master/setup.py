from setuptools import setup, find_packages

setup(
    name='fruit-service',
    packages=find_packages()
)
