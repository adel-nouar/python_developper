# Fruit Service
Fruit Service a small REST API for demonstration purposes.
- Will demonstrate the use of tox
